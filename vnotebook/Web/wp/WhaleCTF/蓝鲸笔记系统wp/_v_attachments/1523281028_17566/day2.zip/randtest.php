<?php 
$randStr = array(); 
for($i=0;$i<50;$i++) {  //�Ȳ��� 32������� 
    $randStr[$i]=rand(0,30); 
    if($i>=31) { 
        echo  "$randStr[$i]=(".$randStr[$i-31]."+".$randStr[$i-3].") mod 31"."\n"; 
    } 
} 
?>