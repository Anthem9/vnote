<?php
echo '1'.is_numeric(233333); # 1
echo '2'.is_numeric('233333'); # 1
echo '3'.is_numeric(0x233333); # 1
echo '4'.is_numeric('0x233333'); # 0
echo '5'.is_numeric('233333abc'); # 0
?>
