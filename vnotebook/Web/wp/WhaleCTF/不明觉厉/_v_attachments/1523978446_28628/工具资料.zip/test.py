#coding:utf8
import requests
import time
url = 'http://daka.whaledu.com/web/web38/9s81jWjd98YU.php'
fa_se=requests.session()
r = fa_se.get(url)
print r.content.find('randcode')
print r.content[r.content.find('randcode')+23:r.content.find('randcode')+26]
print r.content[415:418]